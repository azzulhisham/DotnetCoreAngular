import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OfferService } from '../offer.service';
import { Offer } from 'src/app/models/offer';

@Component({
  selector: 'app-offer-detail-create',
  templateUrl: './offer-detail-create.component.html',
  styleUrls: ['./offer-detail-create.component.scss']
})
export class OfferDetailCreateComponent implements OnInit {
  offer: Offer

  constructor(private offerService: OfferService, public router: Router) { }

  ngOnInit() {
    this.offer = {
      id:null,
      shipmentNumber: null,
      price: 0,
      currency: null,
      vehicleSize: null,
      vehicleBuildUp: null,
      pickupLocationName: null,
      pickupDateTime: 0,
      deliveryLocationName: null,
      deliveryDateTime: 0,
      loadDetail1: null,
      loadDetail2: null,
      loadDetail3: null
    }
  }

  CreateOffer(){
    var answer = confirm(`Are you sure you want to create this offer now?`);
    
    if(answer){
      let newOffer;

      newOffer = {
        shipmentNumber: this.offer.shipmentNumber,
        price: this.offer.price,
        currency: this.offer.currency,
        vehicleSize: this.offer.vehicleSize,
        vehicleBuildUp: this.offer.vehicleBuildUp,
        pickupLocationName: this.offer.pickupLocationName,
        pickupDateTime: this.offer.pickupDateTime,
        deliveryLocationName: this.offer.deliveryLocationName,
        deliveryDateTime: this.offer.deliveryDateTime,
        loadDetail1: this.offer.loadDetail1,
        loadDetail2: this.offer.loadDetail2,
        loadDetail3: this.offer.loadDetail3
      }

      if(this.offer.deliveryDateTime === 0 ||
        this.offer.pickupDateTime === 0 || 
        this.offer.price === 0 ||
        this.offer.deliveryLocationName === '' ||
        this.offer.pickupLocationName === '' ||
        this.offer.shipmentNumber === '' ||
        this.offer.vehicleBuildUp === '' ||
        this.offer.vehicleSize === '' ||
        this.offer.currency === ''
        ){
          alert('Required field cannot be "0" or blank!');
          return false;
      }

      if(this.offer.pickupDateTime > this.offer.deliveryDateTime)
      {
        alert('Invalid pick time and delivery time!');
        return false;
      }

      this.offerService.CreateOffer(newOffer).subscribe(n => {
        console.log(n);
      });
  
      window.location.href = "/";
    }
  }
}
