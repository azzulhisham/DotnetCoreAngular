import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OfferService } from '../offer.service';
import { Observable } from 'rxjs';
import { Offer } from 'src/app/models/offer';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-offer-detail-edit',
  templateUrl: './offer-detail-edit.component.html',
  styleUrls: ['./offer-detail-edit.component.scss']
})
export class OfferDetailEditComponent implements OnInit {

  offer: Offer;

  constructor(private offerService: OfferService, private activatedRoute: ActivatedRoute, public router: Router) { }

  ngOnInit() {
    let offerid = this.activatedRoute.snapshot.params.id; 
  
    var editOffer = new Offer();
    editOffer.id = offerid;

    this.offerService.GetOfferById(editOffer).subscribe(result => {
      this.offer = result;
    });

    console.log(this.offer);
  }

  EditOffer(){
    if(this.offer.deliveryDateTime === 0 ||
      this.offer.pickupDateTime === 0 || 
      this.offer.price === 0 ||
      this.offer.deliveryLocationName === '' ||
      this.offer.pickupLocationName === '' ||
      this.offer.shipmentNumber === '' ||
      this.offer.vehicleBuildUp === '' ||
      this.offer.vehicleSize === '' ||
      this.offer.currency === ''
      ){
        alert('Required field cannot be "0" or blank!');

        return false;
    }

    if(this.offer.pickupDateTime > this.offer.deliveryDateTime)
    {
      alert('Invalid pick time and delivery time!');
      return false;
    }
    
    this.offerService.UpdateOffer(this.offer).subscribe(n => {
      console.log(n);
    });
    
    window.location.href = "/";
  }
}
