import { environment } from '../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Offer } from '../models/offer';

const httpOption = {
  headers : new HttpHeaders({
    'Content-Type': 'application/json; charset=utf-8',
    'Accept': 'application/json',
    'Access-Control-Allow-Origin': '*',
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Methods": "GET,DELETE,POST,PUT",
    "Access-Control-Allow-Headers": "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers"
  })
}

@Injectable({
  providedIn: 'root'
})
export class OfferService {

  constructor(private httpClient: HttpClient) { }

  GetOffers(): Observable<Offer[]> {
    return this.httpClient.get<Offer[]>(`${environment.api}/api/offers`);
  }

  GetOfferById(offer: Offer): Observable<Offer> {
    return this.httpClient.get<Offer>(`${environment.api}/api/offers/${offer.id}`);
  }

  UpdateOffer(offer: any): Observable<Offer> {
    return this.httpClient.put<Offer>(`${environment.api}/api/offers`, offer, httpOption);
  }

  CreateOffer(offer: any): Observable<Offer> {
    console.log(offer);
    return this.httpClient.post<Offer>(`${environment.api}/api/offers`, offer, httpOption);
  }

  DeleteOffer(offer: Offer)
  {
    return this.httpClient.delete(`https://localhost:5001/api/offers/${offer.id}`, httpOption);
  }
}